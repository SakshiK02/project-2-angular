export class BookCategory {
    id: number;
    categoryName: string;
}
